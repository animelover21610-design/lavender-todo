import page from './index.html';

const json = (value, status = 200) => Response.json(value, {
  status, headers: { 'Cache-Control': 'no-store' },
});
const validId = id => typeof id === 'string' && /^[a-f0-9-]{36}$/.test(id);
const validTask = task => task && validId(task.id) &&
  typeof task.title === 'string' && task.title.trim().length > 0 && task.title.trim().length <= 1000 &&
  Number.isInteger(task.day) && task.day >= 0 && task.day <= 6 && typeof task.done === 'boolean';

async function authenticated(request, password) {
  const authorization = request.headers.get('Authorization');
  if (!authorization?.startsWith('Basic ')) return false;
  let credentials;
  try { credentials = atob(authorization.slice(6)); }
  catch { return false; }
  const encoder = new TextEncoder();
  const hash = value => crypto.subtle.digest('SHA-256', encoder.encode(value));
  const [actual, expected] = await Promise.all([hash(credentials), hash('todo:' + password)]);
  return crypto.subtle.timingSafeEqual(actual, expected);
}

export default {
  async fetch(request, env) {
    if (!env.TODO_PASSWORD || env.TODO_PASSWORD.length < 24) {
      return new Response('Set a private to-do list password before using the app.', {status: 503});
    }
    if (!await authenticated(request, env.TODO_PASSWORD)) {
      return new Response('Sign in to your to-do list.', {status: 401, headers: {
        'WWW-Authenticate': 'Basic realm="To Do List", charset="UTF-8"',
        'Cache-Control': 'no-store',
      }});
    }
    const url = new URL(request.url);
    if (url.pathname === '/' && request.method === 'GET') {
      return new Response(page, {headers: {'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store'}});
    }
    if (url.pathname !== '/api/tasks') return json({error: 'Page not found.'}, 404);
    const owner = 'owner';
    try {
      if (request.method === 'GET') {
        const {results} = await env.DB.prepare(
          'SELECT id, title, day, done FROM tasks WHERE owner = ? ORDER BY created_at, id'
        ).bind(owner).all();
        return json(results.map(task => ({...task, done: Boolean(task.done)})));
      }
      if (request.headers.get('Origin') !== url.origin ||
          request.headers.get('Content-Type')?.split(';')[0] !== 'application/json') {
        return json({error: 'Request denied.'}, 403);
      }
      const raw = await request.text();
      if (raw.length > 500000) return json({error: 'This import is too large.'}, 413);
      let body;
      try { body = JSON.parse(raw); }
      catch { return json({error: 'Invalid task data.'}, 400); }
      if (request.method === 'POST') {
        if (!Array.isArray(body) || !body.length || body.length > 500 || !body.every(validTask)) {
          return json({error: 'Enter a task or choose a valid tasks.json file.'}, 400);
        }
        await env.DB.batch(body.map((task, index) => env.DB.prepare(
          'INSERT INTO tasks (owner, id, title, day, done, created_at) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT (owner, id) DO NOTHING'
        ).bind(owner, task.id, task.title.trim(), task.day, Number(task.done), Date.now() + index)));
      } else if (request.method === 'PATCH' && validId(body?.id) && typeof body.done === 'boolean') {
        await env.DB.prepare('UPDATE tasks SET done = ? WHERE owner = ? AND id = ?')
          .bind(Number(body.done), owner, body.id).run();
      } else if (request.method === 'DELETE' && validId(body?.id)) {
        await env.DB.prepare('DELETE FROM tasks WHERE owner = ? AND id = ?').bind(owner, body.id).run();
      } else {
        return json({error: 'Invalid task action.'}, 400);
      }
      return json({ok: true});
    } catch (error) {
      console.error('Task database request failed', error);
      return json({error: 'Couldn’t reach your shared list. Try again.'}, 503);
    }
  },
};
