# Lavender To Do List

A private weekly checklist that syncs between a phone and computer. It opens on
today's tab and imports `tasks.json` from the desktop app.

## Deploy

1. Install Node.js 22 or newer. Sign in to your Cloudflare account with
   `npx wrangler login`.
2. Run `npx wrangler d1 create lavender-todo` and copy the returned database ID
   into `wrangler.toml`.
3. Run `npx wrangler d1 migrations apply DB --remote`.
4. Run `npx wrangler secret put TODO_PASSWORD`. If Wrangler asks to create the
   Worker, confirm. Use a unique random ASCII password at least 24 characters
   long and save it in your password manager.
5. Run `npx wrangler deploy`. Open the HTTPS address Wrangler prints on both
   devices. Use `todo` as the username and enter the same password on each.

Use **Import tasks.json** to bring over a desktop list. The hosted database
starts empty, so a previously hosted list needs to be transferred separately.
On mobile, use your keyboard's microphone to dictate a task.
